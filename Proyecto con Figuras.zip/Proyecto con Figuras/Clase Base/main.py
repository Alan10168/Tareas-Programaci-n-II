from cuadrado import Cuadrado
from triangulo import Triangulo
from circulo import Circulo


def mostrar_menu():
    print("\n" + "=" * 30)
    print("   CÁLCULO DE FIGURAS")
    print("=" * 30)
    print("1. Cuadrado")
    print("2. Triángulo")
    print("3. Círculo")
    print("4. Salir")
    return input("Seleccione una opción: ")


def main():
    while True:
        opcion = mostrar_menu()

        if opcion == "1":
            lado = float(input("Ingrese el valor del lado: "))
            figura = Cuadrado(lado)

        elif opcion == "2":
            base = float(input("Ingrese la base: "))
            altura = float(input("Ingrese la altura: "))
            l1 = float(input("Ingrese lado 1: "))
            l2 = float(input("Ingrese lado 2: "))
            l3 = float(input("Ingrese lado 3 (base): "))
            figura = Triangulo(base, altura, l1, l2, l3)

        elif opcion == "3":
            radio = float(input("Ingrese el radio: "))
            figura = Circulo(radio)

        elif opcion == "4":
            print("Saliendo del programa...")
            break

        else:
            print("Opción no válida, intente de nuevo.")
            continue

        # Mostrar resultados aprovechando el polimorfismo
        print("\n" + "-" * 20)
        print(f"Resultados del {figura.__class__.__name__}:")
        print(f"Área: {figura.area():.2f}")
        print(f"Perímetro: {figura.perimetro():.2f}")
        print("-" * 20)


if __name__ == "__main__":
    main()