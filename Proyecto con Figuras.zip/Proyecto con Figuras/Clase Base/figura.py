from abc import ABC, abstractmethod

class Figura(ABC):
    @abstractmethod
    def area(self):
        """Calcula el área de la figura"""
        pass

    @abstractmethod
    def perimetro(self):
        """Calcula el perímetro de la figura"""
        pass