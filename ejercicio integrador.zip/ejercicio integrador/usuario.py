from abc import ABC, abstractmethod

# La clase debe llamarse exactamente Usuario y ser pública
class Usuario(ABC):
    def __init__(self, nombre):
        self._nombre = nombre

    @abstractmethod
    def descripcion(self):
        pass