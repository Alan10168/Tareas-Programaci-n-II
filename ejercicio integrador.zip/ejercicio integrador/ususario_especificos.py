from usuario import Usuario

class Alumno(Usuario):
    def descripcion(self):
        return f"Alumno: {self._nombre}. Autorizado para préstamos."

class Bibliotecario(Usuario):
    def descripcion(self):
        return f"Bibliotecario: {self._nombre}. Encargado de gestión."