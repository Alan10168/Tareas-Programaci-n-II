class Libro:
    def __init__(self, titulo):
        # Convertir atributo en protegido [cite: 17]
        self._titulo = titulo
        self.disponible = True

    # Crear método getter [cite: 17]
    @property
    def titulo(self):
        return self._titulo
