class GestorPrestamos:
    def __init__(self):
        self.lista_prestamos = []

    def realizar_prestamo(self, libro, usuario):
        # 1. Validar disponibilidad (Requisito Parte 4) [cite: 20]
        if libro.disponible:
            libro.disponible = False

            # 2. Crear el diccionario 'registro' (Esto faltaba en tu captura) [cite: 20]
            registro = {
                "libro": libro.titulo,
                "usuario": usuario._nombre,
                "detalle": usuario.descripcion()
            }

            # 3. Guardarlo en lista [cite: 20]
            self.lista_prestamos.append(registro)
            return True

        return False