# Importaciones corregidas según tus nombres de archivo actuales
from ususario_especificos import Alumno
from libro import Libro
from gestor_prestamos import GestorPrestamos


def main():
    # 1. Crear alumno
    alumno = Alumno("Alan Romero")

    # 2. Crear libro
    libro = Libro("Estructuras de Datos")

    # Instanciar el gestor
    gestor = GestorPrestamos()

    # 3. Realizar préstamo
    resultado = gestor.realizar_prestamo(libro, alumno)

    # 4. Mostrar resultado
    if resultado:
        print("--- Préstamo Registrado ---")
        print(f"Libro: {libro.titulo}")
        print(f"Usuario: {alumno.descripcion()}")
    else:
        print("Error: El libro no se encuentra disponible.")


if __name__ == "__main__":
    main()