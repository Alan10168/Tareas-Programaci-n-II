class Cafeteria:
    def __init__(self, nombre):
        self._nombre = nombre
        self._clientes = []
        self._productos = []

    def registrar_cliente(self, cliente):
        self._clientes.append(cliente)

    def registrar_producto(self, producto):
        self._productos.append(producto)

    def __str__(self):
        return f"Bienvenidos a {self._nombre}"