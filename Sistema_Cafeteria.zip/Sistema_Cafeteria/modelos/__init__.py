# importa las clases aquí para simplificar las rutas

from .cliente import Cliente, ClienteFrecuente
from .producto import Producto
from .pedido import Pedido
from .cafeteria import Cafeteria