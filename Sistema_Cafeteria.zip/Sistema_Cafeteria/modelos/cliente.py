class Cliente:
    def __init__(self, nombre, id_cliente):
        self._nombre = nombre
        self._id_cliente = id_cliente

    def obtener_descuento(self):
        return 0

    def __str__(self):
        return f"Cliente: {self._nombre} (ID: {self._id_cliente})"

class ClienteFrecuente(Cliente):
    def __init__(self, nombre, id_cliente):
        super().__init__(nombre, id_cliente)
        # Establecemos el descuento a 10 %
        self._descuento = 10

    def obtener_descuento(self):
        return self._descuento

    def __str__(self):
        return f"Cliente Frecuente: {self._nombre} (ID: {self._id_cliente}) - Descuento Aplicado: {self._descuento}%"