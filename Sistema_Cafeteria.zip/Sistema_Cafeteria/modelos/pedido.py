class Pedido:
    def __init__(self, cliente):
        self._cliente = cliente
        self._productos = []

    def agregar_producto(self, producto):
        self._productos.append(producto)

    def calcular_total(self):
        subtotal = sum(p._precio for p in self._productos)
        descuento = (subtotal * self._cliente.obtener_descuento()) / 100
        return subtotal - descuento

    def __str__(self):
        nombres_prod = ", ".join([p._nombre for p in self._productos])
        return f"Ticket -> Cliente: {self._cliente._nombre} | Productos: [{nombres_prod}] | Total con desc: ${self.calcular_total():.2f}"