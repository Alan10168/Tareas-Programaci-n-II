from modelos.cliente import Cliente, ClienteFrecuente
from modelos.producto import Producto
from modelos.pedido import Pedido


def menu():
    print("\n--- SISTEMA DE CAFETERÍA UAEMÉX ---")

    # 1. Registro de Productos (Tú los ingresas)
    productos_menu = []
    for i in range(2):
        print(f"\nProducto {i + 1}:")
        nom = input("Nombre: ")
        pre = float(input("Precio: "))
        productos_menu.append(Producto(nom, pre))

    # 2. Registro de Clientes
    print("\n--- REGISTRO DE CLIENTES ---")
    nom_n = input("Nombre Cliente Normal: ")
    id_n = input("ID: ")
    cliente_normal = Cliente(nom_n, id_n)

    nom_f = input("Nombre Cliente Frecuente: ")
    id_f = input("ID: ")
    # se aplica solo el 10%
    cliente_frecuente = ClienteFrecuente(nom_f, id_f)

    # 3. Creación de Pedidos
    ped1 = Pedido(cliente_normal)
    ped1.agregar_producto(productos_menu[0])
    ped1.agregar_producto(productos_menu[1])

    ped2 = Pedido(cliente_frecuente)
    ped2.agregar_producto(productos_menu[0])
    ped2.agregar_producto(productos_menu[1])

    # 4. Resultados
    print("\n" + "=" * 30)
    print("DETALLE DE PEDIDOS")
    print("=" * 30)
    print(ped1)
    print(ped2)
    print("=" * 30)


if __name__ == "__main__":
    menu()